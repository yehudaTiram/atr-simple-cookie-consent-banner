/** @format */

// scb-script.js - Vanilla JS cookie consent
(function () {
  const name = (window.scbSettings && scbSettings.cookieName) || "scb_consent";
  const expiryDays = (window.scbSettings && scbSettings.expiryDays) || 365;

  // Prevent multiple initializations
  if (window.scbInitialized) return;
  window.scbInitialized = true;

  function saveConsent(obj) {
    try {
      localStorage.setItem(name, JSON.stringify(obj));
    } catch (e) {
      // fallback to cookie
      const v = encodeURIComponent(JSON.stringify(obj));
      document.cookie =
        name + "=" + v + ";path=/;max-age=" + expiryDays * 24 * 60 * 60;
    }
  }

  function getConsent() {
    try {
      const v = localStorage.getItem(name);
      if (v) return JSON.parse(v);
    } catch (e) {}
    // fallback read cookie
    const match = document.cookie.match(
      new RegExp("(^| )" + name + "=([^;]+)")
    );
    if (match) {
      try {
        return JSON.parse(decodeURIComponent(match[2]));
      } catch (e) {}
    }
    return null;
  }

  function consentGivenFor(key) {
    const c = getConsent();
    return c && c[key] === true;
  }

  // Replace <script type="text/plain" data-consent="analytics" src="..."></script>
  function activateDataScripts(type) {
    const nodes = document.querySelectorAll(
      'script[type="text/plain"][data-consent="' + type + '"]'
    );
    nodes.forEach((n) => {
      const s = document.createElement("script");
      if (n.src) s.src = n.src;
      if (n.textContent) s.textContent = n.textContent;
      // copy attributes except type
      for (let i = 0; i < n.attributes.length; i++) {
        const a = n.attributes[i];
        if (a.name === "type" || a.name === "data-consent") continue;
        s.setAttribute(a.name, a.value);
      }
      n.parentNode.replaceChild(s, n);
    });
  }

  function showBanner() {
    const banner = document.getElementById("scb-banner");
    const overlay = document.getElementById("scb-overlay");
    
    if (banner && overlay) {
      // Add body class to prevent scroll
      document.body.classList.add('scb-open');
      
      // Show overlay and banner with smooth transitions
      overlay.classList.add('visible');
      banner.classList.add('visible');
    }
  }

  function hideBanner() {
    const banner = document.getElementById("scb-banner");
    const overlay = document.getElementById("scb-overlay");
    const settings = document.getElementById("scb-settings");
    
    if (banner && overlay) {
      // Remove body class to restore scroll
      document.body.classList.remove('scb-open');
      
      // Hide overlay and banner with smooth transitions
      overlay.classList.remove('visible');
      banner.classList.remove('visible');
      
      if (settings) settings.hidden = true;
    }
  }

  function setLoadingState(loading) {
    const banner = document.getElementById("scb-banner");
    if (banner) {
      if (loading) {
        banner.classList.add('loading');
      } else {
        banner.classList.remove('loading');
      }
    }
  }

  // Initialize the banner
  function initBanner() {
    const banner = document.getElementById("scb-banner");
    const overlay = document.getElementById("scb-overlay");
    const settings = document.getElementById("scb-settings");
    const form = document.getElementById("scb-form");

    // Check if banner elements exist
    if (!banner || !overlay) {
      console.warn('Cookie consent banner elements not found');
      return;
    }

    const stored = getConsent();
    if (stored) {
      // User has already given consent - activate scripts and don't show banner
      if (stored.analytics) activateDataScripts("analytics");
      if (stored.marketing) activateDataScripts("marketing");
      return;
    }

    // No consent yet - show banner after a short delay to prevent flash
    setTimeout(() => {
      showBanner();
    }, 100);

    // controls
    const btnAcceptAll = document.getElementById("scb-btn-accept-all");
    const btnReject = document.getElementById("scb-btn-reject");
    const btnCustom = document.getElementById("scb-btn-custom");
    const btnCancel = document.getElementById("scb-btn-cancel");

    btnAcceptAll &&
      btnAcceptAll.addEventListener("click", function () {
        setLoadingState(true);
        
        const c = {
          essential: true,
          analytics: true,
          marketing: true,
          ts: Date.now(),
        };
        
        saveConsent(c);
        activateDataScripts("analytics");
        activateDataScripts("marketing");
        
        setTimeout(() => {
          hideBanner();
          setLoadingState(false);
        }, 300);
      });

    btnReject &&
      btnReject.addEventListener("click", function () {
        setLoadingState(true);
        
        const c = {
          essential: true,
          analytics: false,
          marketing: false,
          ts: Date.now(),
        };
        
        saveConsent(c);
        
        setTimeout(() => {
          hideBanner();
          setLoadingState(false);
        }, 300);
      });

    btnCustom &&
      btnCustom.addEventListener("click", function () {
        if (settings) {
          settings.hidden = !settings.hidden;
        }
      });

    btnCancel &&
      btnCancel.addEventListener("click", function () {
        if (settings) settings.hidden = true;
      });

    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        setLoadingState(true);
        
        const formd = new FormData(form);
        const c = {
          essential: true,
          analytics:
            formd.get("analytics") === "on" ||
            formd.get("analytics") === "true",
          marketing:
            formd.get("marketing") === "on" ||
            formd.get("marketing") === "true",
          ts: Date.now(),
        };
        
        saveConsent(c);
        if (c.analytics) activateDataScripts("analytics");
        if (c.marketing) activateDataScripts("marketing");
        
        setTimeout(() => {
          hideBanner();
          setLoadingState(false);
        }, 300);
      });
    }

    // Close banner when clicking outside (mobile-friendly)
    overlay.addEventListener("click", function(e) {
      if (e.target === overlay) {
        hideBanner();
      }
    });

    // Close banner with Escape key
    document.addEventListener("keydown", function(e) {
      if (e.key === "Escape") {
        hideBanner();
      }
    });
  }

  // Wait for DOM to be ready, but also check if elements are already there
  function ready() {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", initBanner);
    } else {
      // DOM is already ready
      initBanner();
    }
  }

  // Start initialization
  ready();

  // expose for debugging / admin
  window.scb = {
    getConsent,
    saveConsent,
    consentGivenFor,
    activateDataScripts,
    showBanner,
    hideBanner,
  };
})();
